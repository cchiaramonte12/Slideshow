/**
 * Homework 2b
 * Cameron Chiaramonte, ccc7sej
 * 
 * Sources: TA OH, Big Java Book
 */
public class Album extends PhotoContainer {
	
	/**
	 * this is a constructor to initialize the name and photos fields
	 * @param newName the new inputted name for the album
	 */
	public Album(String newName) {
		super(newName);
	}	
}
